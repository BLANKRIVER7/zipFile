    function logout() {
        location.href = 'logout'
    }