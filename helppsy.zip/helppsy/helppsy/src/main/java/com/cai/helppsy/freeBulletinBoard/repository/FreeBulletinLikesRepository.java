package com.cai.helppsy.freeBulletinBoard.repository;

import com.cai.helppsy.freeBulletinBoard.entity.FreeBulletinLikes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FreeBulletinLikesRepository extends JpaRepository<FreeBulletinLikes, Integer> {

}
