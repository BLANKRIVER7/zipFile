package com.cai.helppsy.serviece;

public class FreeBulletinBoardService {
}
