package com.cai.helppsy.likes.dto;

import lombok.Data;

@Data
public class FreeBulletinLikeDTO {
    private int no;
    private String type;
    private String userName;
}
