package com.cai.helppsy.likes.dto;

import lombok.Data;

@Data
public class FreeBulletinReplyLikeDTO {
    private int no;
    private String type;
    private String userName;

}
