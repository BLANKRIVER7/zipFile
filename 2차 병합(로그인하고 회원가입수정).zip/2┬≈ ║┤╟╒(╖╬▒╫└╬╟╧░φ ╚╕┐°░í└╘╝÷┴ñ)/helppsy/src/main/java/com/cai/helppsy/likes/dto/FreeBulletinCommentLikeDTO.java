package com.cai.helppsy.likes.dto;

import lombok.Data;

@Data
public class FreeBulletinCommentLikeDTO {
    private int no;
    private String type;
    private String userName;
    private int isPressedCommentLike;
}
